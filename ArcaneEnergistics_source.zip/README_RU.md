# Arcane Energistics — исходный проект

Аддон для Minecraft 26.1.2 + NeoForge, задуманный как мост между Thaumaturge и Applied Energistics 2.

## Важно
Это исходный каркас для разработки, а не готовый проверенный `.jar`. Он добавляет собственные предметы и рецепты через datapack-ресурсы. Поскольку API и registry ID Thaumaturge/AE2 могут меняться между сборками, сначала проверьте версии модов и затем соберите/запустите проект. Функции, требующие API конкретных модов (автоматизация инфузии, хранение эссенции в ME), не притворяются реализованными в этой первой заготовке.

На CurseForge уже появился отдельный проект **Applied Thaumaturge**, который описывает почти точно эту идею: хранение эссенции в ME-сети и автоматизация arcane crafting. Проверьте его, прежде чем ставить два аддона одновременно:
https://www.curseforge.com/minecraft/mc-mods/applied-thaumaturge

## Цели прототипа
- Добавить арканный кристалл и арканный ME-компонент.
- Добавить взаимосвязанные рецепты с ранним этапом магии и технологий.
- Сохранить прогрессию: компоненты требуют ресурсы обеих веток.
- Не подменять неизвестные registry ID выдуманными: рецепты интеграции отмечены TODO и должны быть привязаны к фактическим ID из установленных jar.

## Структура
- `src/main/java/.../ArcaneEnergistics.java` — регистрация предметов.
- `src/main/resources/META-INF/neoforge.mods.toml` — метаданные мода.
- `src/main/resources/data/arcane_energistics/recipe/` — рецепты-примеры.
- `src/main/resources/assets/arcane_energistics/lang/en_us.json` и `ru_ru.json` — названия.

## Сборка
1. Установите JDK 25 (Minecraft 26.1.2 / текущий AE2 используют Java 25).
2. Скачайте официальный MDK для NeoForge 26.1.2: https://github.com/NeoForgeMDKs/MDK-26.1.2-ModDevGradle
3. В проекте есть базовые `build.gradle`, `settings.gradle` и `gradle.properties`, но не включён Gradle Wrapper. Скачайте официальный MDK и возьмите из него `gradlew`, `gradlew.bat` и каталог `gradle/wrapper/`. Если Gradle сообщит о несовместимости, используйте `build.gradle` и `gradle.properties` непосредственно из официального MDK, затем перенесите в них настройки `mod_id`, `mod_name`, `mod_version` и `mod_group_id` из этого проекта.
4. В `gradle.properties` установите `minecraft_version=26.1.2`, `neo_version=26.1.2.21-beta` (или актуальную совместимую NeoForge 26.1.2 из официального списка).
5. В `build.gradle` задайте `group = "dev.arcaneenergistics"` и `version = "0.1.0"`, а имя мода — `arcane_energistics`.
6. Запустите `gradlew runClient` (Windows: `gradlew.bat runClient`) и проверьте запуск.
7. Соберите: `gradlew build`. Результат будет в `build/libs/`.
8. Установите итоговый jar и зависимости в отдельный тестовый профиль; сначала сделайте резервную копию мира.

## Дальнейшая работа для настоящей интеграции
1. Получить точные registry ID предметов Thaumaturge для кристаллов/эссенции/инструментов.
2. Проверить ID AE2 для инженерных компонентов, процессоров и ME-компонентов.
3. Добавить зависимости `modId` и compileOnly API, если обе библиотеки доступны для выбранных версий.
4. Реализовать интеграцию с API Thaumaturge для инфузии и с API AE2 для ME-хранилища/автоматизации.
5. Проверить рецепты на dedicated server и клиенте.

Не ставьте одновременно другой аддон, меняющий те же рецепты/механику, пока не проверите совместимость.
