Place 16x16 PNG textures here: arcane_circuit.png, resonant_crystal.png, essentia_processor.png, arcane_me_core.png. Placeholder item models will be invisible/missing-texture until these are added.
