package dev.arcaneenergistics;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

/**
 * Minimal content registration for Arcane Energistics.
 * Compile this against the official NeoForge 26.1.2 MDK; APIs may evolve in beta builds.
 */
@Mod(ArcaneEnergistics.MOD_ID)
public final class ArcaneEnergistics {
    public static final String MOD_ID = "arcane_energistics";

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);

    public static final DeferredItem<Item> ARCANE_CIRCUIT =
            ITEMS.register("arcane_circuit", () -> new Item(new Item.Properties()));
    public static final DeferredItem<Item> RESONANT_CRYSTAL =
            ITEMS.register("resonant_crystal", () -> new Item(new Item.Properties()));
    public static final DeferredItem<Item> ESSENTIA_PROCESSOR =
            ITEMS.register("essentia_processor", () -> new Item(new Item.Properties()));
    public static final DeferredItem<Item> ARCANE_ME_CORE =
            ITEMS.register("arcane_me_core", () -> new Item(new Item.Properties()));

    public ArcaneEnergistics(IEventBus modBus) {
        ITEMS.register(modBus);
    }
}
